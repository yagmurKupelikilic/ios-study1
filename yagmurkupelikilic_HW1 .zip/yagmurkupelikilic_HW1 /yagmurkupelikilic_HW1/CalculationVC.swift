//
//  CalculationVC.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 29.03.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit



class CalculationVC: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, InputControllerDelegate {
    
    func inputControllerDelegate(controller: InputVC, data: (r: Double, h: Double)) {
        
        self.navigationController?.popViewController(animated: true)
       
        if index == 0 {
            print("yagmur")
            let sa = sphereArea(r: data.r)
            let v = sphereVolume(r: data.r)
            let result = String(format: "Sphere Surface Area = %0.2f and Volume = %0.2f", sa, v)
            displayAlertDialog(header: "Result", msg: result)
        }else if index == 1 {
            let sa = coneArea(r: data.r, h: data.h)
            let v = coneVolume(r: data.r, h: data.h)
            let result = String(format: "Cone Surface Area = %0.2f and Volume = %0.2f", sa, v)
            displayAlertDialog(header: "Result", msg: result)
        }else if index == 2 {
            let sa = cylinderArea(r: data.r, h: data.h)
            let v = cylinderVolume(r: data.r, h: data.h)
            let result = String(format: "Cone Surface Area = %0.2f and Volume = %0.2f", sa, v)
            displayAlertDialog(header: "Result", msg: result)
        }
        
           
    }
    
    
    
    @IBOutlet weak var mImage: UIImageView!
    @IBOutlet weak var mPickerView: UIPickerView!
    let shapes = ["sphere", "cone", "cylinder"]
    var index = 0
  
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return shapes.count
    }
    
    // Called automatically multiple times. To attach the data
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return shapes[row]
    }
    
    // Called when an item in pickerView is selected
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch row {
        case 0:
            mImage.image = UIImage(named: "sphere.jpg")
        case 1:
            mImage.image = UIImage(named: "cone.jpg")
        case 2:
            mImage.image = UIImage(named: "cylinder.jpg")
            
        default:
            mImage.image = UIImage(named: "sphere.jpg")
            
        }
        index = row
        
        
    }
    
    @IBAction func inputButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "input", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "input" {
        let vc = segue.destination as! InputVC
        // Passing data from the InputVC
        vc.delegate = self
        // changing navigationItem.title in terms of selected pickerView
        vc.navTitle = shapes[index]
        vc.index = index
        }
    }
    
    
    func sphereArea(r:Double) -> Double{
        return ( 4.0 * .pi * pow(r,2.0))
    }
    
    func sphereVolume(r:Double) -> Double{
        return (4.0/3.0 * .pi * pow(r,3.0))
    }
    
    func coneArea(r:Double,h:Double) -> Double {
        return ( .pi * r * ( r * sqrt(pow(r,2.0) * pow(h,2.0))))
    }
    
    func coneVolume(r:Double, h:Double) -> Double {
        return (1.0/3.0 * .pi * pow(r,2.0) * h)
    }
    
    func cylinderArea(r:Double, h:Double) -> Double {
        return ( 2 * .pi * r * ( h + r ))
    }
    
    func cylinderVolume(r:Double, h:Double) -> Double {
        return ( .pi * pow(r,2.0) * h)
    }
    
    func displayAlertDialog(header: String, msg: String){
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: .alert)
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        self.present(mAlert, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
}
