//
//  ViewController.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 28.03.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class StartVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    let colors = ["red", "green", "blue", "yellow", "pink"]
    // game picker view data
    var selectedPickerView = 0
    var ctr = 0
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return colors.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return colors[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch row {
        case 0:
            selectedPickerView = row
           
        case 1:
            selectedPickerView = row
           
        case 2:
            selectedPickerView = row
            
        case 3:
            selectedPickerView = row
           
        case 4:
           selectedPickerView = row
         
            
        default:
            break
        }
    
    }
    
    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var mView: UIView!
    @IBOutlet weak var mImageView: UIImageView!
    @IBOutlet weak var mPickerView: UIPickerView!
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    
    
    @IBAction func unWind(_ sender: UIStoryboardSegue){
    }
    
    
    @IBAction func onSegmentedControl(_ sender: UISegmentedControl) {
        
        switch mSegmentedControl.selectedSegmentIndex {  // switch sender.selectedSegmentIndex
        case 0:
            mLabel.text = "Calculation Conntroller"
            mImageView.image = UIImage(named: "calculation.jpg")
            mPickerView.isHidden = true
            
        case 1:
            mLabel.text = "WHtR Controller"
            mImageView.image = UIImage(named: "whtr.jpg")
            mPickerView.isHidden = true
            
        case 2:
            mLabel.text = "Game Controller"
            mImageView.image = UIImage(named: "game.jpg")
            mPickerView.isHidden = false
            
        case 3:
            mLabel.text = "Player Controller"
            mImageView.image = UIImage(named: "player.jpg")
            mPickerView.isHidden = true
            
            
        case 4:
            mLabel.text = "About Controller"
            mImageView.image = UIImage(named: "about.jpg")
            mPickerView.isHidden = true
        default:
            break
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "about" {
            // Passing data to the AboutVC
            let vc = segue.destination as! AboutVC
            vc.firstLabel = "About Controller"
            vc.secondLabel = "CTIS 480: HOMEWORK - I "
            vc.labelColor = .red
            vc.labelFont = UIFont.boldSystemFont(ofSize: 24.0)
            
        }else if segue.identifier == "game" {
            // Passing pickerView index selected to GameVC
            if let vc2 = segue.destination as? GameVC {
            vc2.counter = ctr
            //vc2.counter = selectedPickerView
            vc2.colorIndex = selectedPickerView
           }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        mPickerView.isHidden = true
        
        // Long Press
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(gesture:)))
        mImageView.addGestureRecognizer(longPressGesture)
        //
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(singleTap(gesture:)))
        mImageView.addGestureRecognizer(tapGesture)
        
    }
    
    @IBAction func singleTap(gesture: UITapGestureRecognizer) {
        if(mSegmentedControl.selectedSegmentIndex == 0){
            mSegmentedControl.selectedSegmentIndex = 1
            mImageView.image = UIImage(named: "whtr.jpg")
            mPickerView.isHidden = true
            mLabel.text = "Whtr Controller"
            //print("Segmedted control is 111111")
            print(mSegmentedControl.selectedSegmentIndex)
        }else if(mSegmentedControl.selectedSegmentIndex == 1){
            mSegmentedControl.selectedSegmentIndex = 2
            mImageView.image = UIImage(named: "game.jpg")
            mLabel.text = "Game Controller"
            mPickerView.isHidden = false
            print(mSegmentedControl.selectedSegmentIndex)
        }else if(mSegmentedControl.selectedSegmentIndex == 2){
            mSegmentedControl.selectedSegmentIndex = 3
            mImageView.image = UIImage(named: "player.jpg")
            mLabel.text = "Player Controller"
            mPickerView.isHidden = true
            print(mSegmentedControl.selectedSegmentIndex)
        }else if(mSegmentedControl.selectedSegmentIndex == 3){
            mSegmentedControl.selectedSegmentIndex = 4
            mImageView.image = UIImage(named: "about.jpg")
            mLabel.text = "About Controller"
            mPickerView.isHidden = true
            print(mSegmentedControl.selectedSegmentIndex)
        }else{
            mSegmentedControl.selectedSegmentIndex = 0
            mImageView.image = UIImage(named: "calculation.jpg")
            mLabel.text = "Calculation Controller"
            mPickerView.isHidden = true
            print(mSegmentedControl.selectedSegmentIndex)
        }
        
    }
    
    
    
    //Long press action
    @objc func handleLongPress(gesture: UILongPressGestureRecognizer) {
       // mLabel.text = "Long press recognized"
        
        if(mSegmentedControl.selectedSegmentIndex == 0){
            performSegue(withIdentifier: "calculation", sender: self)
        }else if(mSegmentedControl.selectedSegmentIndex == 1){
            performSegue(withIdentifier: "whtr", sender: self)
        }else if(mSegmentedControl.selectedSegmentIndex == 2){
            //ctr += 1
            print(ctr) 
            performSegue(withIdentifier: "game", sender: self)
        }else if(mSegmentedControl.selectedSegmentIndex == 3){
            performSegue(withIdentifier: "player", sender: self)
        }else {
        performSegue(withIdentifier: "about", sender: self)
        }
        
        
        
        
    }
    
}



