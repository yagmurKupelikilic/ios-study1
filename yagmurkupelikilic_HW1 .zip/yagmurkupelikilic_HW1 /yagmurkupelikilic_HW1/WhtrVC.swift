//
//  WhtrVC.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 1.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class WhtrVC: UIViewController {
    
    @IBOutlet weak var heightText: UITextField!
    @IBOutlet weak var waistText: UITextField!
    @IBOutlet weak var selectedGender: UILabel!
    @IBOutlet weak var mSwitch: UISwitch!
    @IBOutlet weak var outputText: UILabel!
    @IBOutlet weak var healthStatusText: UILabel!
    
    
    @IBAction func onValueChanged(_ sender: UISwitch) {
        if sender.isOn {
            selectedGender.text = "Gender (male)"
        } else {
            selectedGender.text = "Gender (female)"
        }
    }
    
    
    func calculate(waist:Double, height:Double) -> Double {
        let out = (waist / height) * 100
        return out
    }
    
    
    @IBAction func calculateDone(_ sender: Any) {
        
        var healthStatus = ""
        let gender = mSwitch.isOn
           
        if heightText.text!.isEmpty || waistText.text!.isEmpty {
            displayAlertDialog(header: "Entered Data", msg: "Height or Waist cannot be empty! ")
        }
            
        else{
            let waist = Double(waistText.text!)!
            let height = Double(heightText.text!)!
            
            //  let calculation:Double! = (waist / height) * 100
            let calculation = calculate(waist: waist, height: height)
            
            //String version of calculated values
            let result = String(format: "%0.2f", calculation)
            
            
            outputText.isHidden = false
            healthStatusText.isHidden = false
            self.healthStatusText.text! = healthStatus
            
            switch gender{
                
            case true:
                self.outputText.text! = "WHtR(male): " + " " + result
                if calculation < 35{
                    healthStatus = "Abnormally Slim to Underweight"
                }else if  (35 <= calculation) && (calculation <= 43){
                    healthStatus = "Extremely slim"
                }else if (43 <= calculation) && (calculation <= 46){
                    healthStatus = "Slender and Healthy"
                }else if (46 <= calculation) && (calculation <= 53){
                    healthStatus = "Healthy, Normal Weight"
                }else if (53 <= calculation) && (calculation <= 58){
                    healthStatus = "Overweight"
                }else if (58 <= calculation) && (calculation <= 63){
                    healthStatus = "Extremely Overweight/Obese"
                }else{
                    healthStatus = "Highly Obese"
                }
                
                
            case false:
                self.outputText.text! = "WHtR(female):  " + " " + result
                if calculation < 35{
                    healthStatus = "Abnormally Slim to Underweight"
                }else if  (35 <= calculation) && (calculation <= 42){
                    healthStatus = "Extremely slim"
                }else if (42 <= calculation) && (calculation <= 46){
                    healthStatus = "Slender and Healthy"
                }else if (46 <= calculation) && (calculation <= 49){
                    healthStatus = "Healthy, Normal Weight"
                }else if (49 <= calculation) && (calculation <= 54){
                    healthStatus = "Overweight"
                }else if (54 <= calculation) && (calculation <= 58){
                    healthStatus = "Extremely Overweight/Obese"
                }else{
                    healthStatus = "Highly Obese"
                }
                
            }
            
            self.healthStatusText.text! = healthStatus
        }
        
    }
    
    func displayAlertDialog(header: String, msg: String){
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: .alert)
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        self.present(mAlert, animated: true, completion: nil)
        
    }
    
    // Clicking the view (the container for UI components) removes the Keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        outputText.isHidden = true
        healthStatusText.isHidden = true
        
        // Do any additional setup after loading the view.
    }
    
    
    
}
