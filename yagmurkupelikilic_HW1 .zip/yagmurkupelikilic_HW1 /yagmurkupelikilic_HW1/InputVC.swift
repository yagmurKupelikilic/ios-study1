//
//  InputVC.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 30.03.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

protocol InputControllerDelegate {
    func inputControllerDelegate(controller: InputVC, data: (r: Double, h: Double))
}

class InputVC: UIViewController {
    
    var delegate: InputControllerDelegate? //object to store a reference
    
    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var radius: UITextField!
    @IBOutlet weak var height: UITextField!
    @IBOutlet weak var mTextField: UITextField!
    @IBOutlet weak var label: UILabel!
    
    
    var navTitle = ""
    var index = 0 // pickerView selected item
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        navItem.title = navTitle
        
        //pickerView selected item InputVC displayed
        switch index {
        case 0:
            height.isHidden = true
            label.isHidden = true
            radius.placeholder = "Enter radius value"
        case 1:
            height.isHidden = false
            label.isHidden = false
            //radius.placeholder = "Enter radius value"
            //height.placeholder = "Enter height value"
        case 2:
            height.isHidden = false
            label.isHidden = false
            //radius.placeholder = "Enter radius value"
           //height.placeholder = "Enter height value"
        default:
            height.isHidden = true
            label.isHidden = true
            break
        }
        
        
        
    }
    func getData() -> (Double, Double){
        var mRadius = 1.0
        var mHeight = 1.0
        
        if(index == 0) {
       
            mRadius = Double(radius.text!)!
        }else{
            mHeight = Double(height.text!)!
            mRadius = Double(radius.text!)!
        }
        
        return (mRadius, mHeight)
        
    }
    
    
    @IBAction func onDonePressed(_ sender: UIBarButtonItem) {
       // mRadius = radius.text!
       // mHeight = height.text!
        if(index == 0){
            if(radius.text!.isEmpty){
                displayAlertDialog(header: "Entered Data", msg: "Radius cannot be empty! ")
            }else {
                delegate?.inputControllerDelegate(controller: self, data: getData())
            }
        }else {
            if(radius.text!.isEmpty || height.text!.isEmpty){
                displayAlertDialog(header: "Entered Data", msg: "Radius or height cannot be empty! ")
            }else {
                delegate?.inputControllerDelegate(controller: self, data: getData())
            }
            
        }
    }
    
    
    func displayAlertDialog(header: String, msg: String){
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: .alert)
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        self.present(mAlert, animated: true, completion: nil)
        
    }
    
    // Clicking the view (the container for UI components) removes the Keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
}
