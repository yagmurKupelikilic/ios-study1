//
//  AboutVC.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 31.03.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit



class AboutVC: UIViewController {

    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var mText: UILabel!
    
    var labelColor: UIColor?
    var labelFont: UIFont?
    
    var firstLabel = ""
    var secondLabel = ""
   
    override func viewDidLoad() {
        super.viewDidLoad()
    
        mLabel.text = firstLabel
        mText.text = secondLabel
        mText.textColor = labelColor
        mText.font = labelFont
        }
        
}
    


