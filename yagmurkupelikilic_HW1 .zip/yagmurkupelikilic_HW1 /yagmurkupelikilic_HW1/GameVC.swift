//
//  GameVC.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 2.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class GameVC: UIViewController {
    @IBOutlet var mImageCollection1: [UIImageView]!
    @IBOutlet var mImageCollection2: [UIImageView]!
   
    
    
    var counter = 0
    var colorIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        var color = UIColor.red
        
        
        switch colorIndex {
        case 0:
            color = UIColor.red
        case 1:
            color = UIColor.green
        case 2:
            color = UIColor.blue
        case 3 :
            color = UIColor.yellow
        default:
            color = UIColor.systemPink
        }
       
       if counter % 2 == 1 { //odd from right to left Collection 1
            for x in 0..<mImageCollection1.count {
                
                mImageCollection2[x].backgroundColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
                mImageCollection1[x].backgroundColor = color
            }
       }else { //even from left to right Collection2
            for x in 0..<mImageCollection2.count {
                
                mImageCollection1[x].backgroundColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
                mImageCollection2[x].backgroundColor = color
            }
        }
        
        
    }
}

