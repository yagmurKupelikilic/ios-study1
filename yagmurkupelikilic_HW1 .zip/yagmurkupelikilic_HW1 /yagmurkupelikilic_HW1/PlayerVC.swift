//
//  PlayerVC.swift
//  yagmurkupelikilic_HW1
//
//  Created by CTIS Student on 3.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class PlayerVC: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITableViewDelegate, UITableViewDataSource{
    
    
    @IBOutlet weak var mTableView: UITableView!
    @IBOutlet weak var mPickerView: UIPickerView!
       
    var teamPlayers = [String]()
    var allPlayers = [(String, String)]()
    var tableViewFilled = [Int](repeating: 0, count: 3)
    
    
    func populateData(team: String) {
        
        if let path = Bundle.main.path(forResource: "players", ofType: "plist") {
            if let dictArray = NSArray(contentsOfFile: path) {
                for item in dictArray {
                    if let dict = item as? NSDictionary {
                        if (dict.allKeys[0] as! String) == team {
                            teamPlayers.append(dict.allValues[0] as! String)
                        }
                    }
                }
            }
        }
    }
    
    
    @IBAction func BesiktasTapGesture(_ sender: UITapGestureRecognizer) {
        teamPlayers.removeAll()
        populateData(team: "besiktas")
        mPickerView.reloadAllComponents()
        
        if tableViewFilled[0] == 0 {
            tableViewFilled[0] = 1
            
            for x in 0..<teamPlayers.count {
                allPlayers.append((teamPlayers[x], "besiktas"))
            }
            mTableView.reloadData()
        }
        
    }
    
    @IBAction func FenerbahceTapGesture(_ sender: UITapGestureRecognizer) {
        teamPlayers.removeAll()
        populateData(team: "fenerbahce")
        mPickerView.reloadAllComponents()
        
        if tableViewFilled[1] == 0 {
            tableViewFilled[1] = 1
            
            for x in 0..<teamPlayers.count {
                allPlayers.append((teamPlayers[x], "fenerbahce"))
            }
            mTableView.reloadData()
        }
        
        
    }
    
    
    @IBAction func GalatasarayTapGesture(_ sender: UITapGestureRecognizer){
        
        teamPlayers.removeAll()
        populateData(team: "galatasaray")
        mPickerView.reloadAllComponents()
        
        if tableViewFilled[2] == 0 {
            tableViewFilled[2] = 1
            
            for x in 0..<teamPlayers.count {
                allPlayers.append((teamPlayers[x], "galatasaray"))
            }
            mTableView.reloadData()
        }
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPlayers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        let (player, team) = allPlayers[indexPath.row]
        // Setting the data for the cell (optional chaining)
        cell.textLabel?.text = player
        cell.imageView?.image = UIImage(named: team)
        
        return cell
    }
    
    
    
    
    // The number spinning wheels (i.e., columns)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    // The number of items/rows in the componets
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return teamPlayers.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return teamPlayers[row]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
}
